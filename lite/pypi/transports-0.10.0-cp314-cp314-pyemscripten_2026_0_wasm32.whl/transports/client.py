"""Mirror a remote `Session` from connection messages.

`Client.recv(text)` applies snapshot/patch messages to a local mirror using the core `apply`, so the
client tracks each remote model's value without hosting it. `connect(url)` runs a real WebSocket
client loop for live use; `connect_data_channel(channel)` does the same for an externally negotiated
WebRTC data channel under Pyodide. `attach(sender)` and `detach(sender)` manage other
application-owned duplex channels while inbound frames continue through `recv`.
"""

import contextlib
import inspect
import json
import sys
import urllib.parse
import uuid
from collections.abc import Callable
from typing import Any

from . import protocol
from ._bridge import M, _value_of, from_value
from .crdt import CrdtDocument, CrdtSpec
from .transports import ClientState as _ClientState, apply as _apply, diff as _diff


class Client:
    """Mirrors a remote `Session` — applies snapshot/patch messages to a local copy of each model.

    Read values with `value(id)` or materialize them with `model(id, cls)`. Drive it with a live
    connection via `connect(url)`, attach an application-owned duplex sender, or feed it messages
    directly with `recv(data)`. The `codec` (`"json"`, `"msgpack"`, or `"cbor"`) frames outbound
    edits and decodes inbound frames."""

    def __init__(self, codec: str = protocol.JSON) -> None:
        self._values: dict[int, Any] = {}
        self._type: dict[int, str] = {}
        self._state = _ClientState()
        self._replica = f"client-{uuid.uuid4().hex}"
        self._crdt: dict[int, CrdtDocument] = {}
        self._crdt_outbox: list[dict] = []
        self._codec = protocol.normalize_codec(codec)
        self._change_cbs: list[Callable[[dict], None]] = []
        self._awareness: dict[int, dict[str, Any]] = {}
        self._local_awareness: dict[int, str | bytes] = {}
        self._awareness_cbs: list[Callable[[dict], None]] = []
        self._ack_cbs: list[Callable[[dict], None]] = []
        self._reject_cbs: list[Callable[[dict], None]] = []
        self._abandon_cbs: list[Callable[[list[str]], None]] = []
        self._connect_cbs: list[Callable[[], None]] = []
        self._disconnect_cbs: list[Callable[[], None]] = []
        #: outbound channel of the active managed connection (set by `attach`, cleared by `detach`)
        self._sender: Callable[[str | bytes], Any] | None = None

    @property
    def connected(self) -> bool:
        """Whether a managed duplex connection is open right now."""
        return self._sender is not None

    @property
    def _rev(self) -> dict[int, int]:
        """Compatibility view of revisions now owned by the shared core."""
        return {int(mid): rev for mid, rev in json.loads(self._state.revisions()).items()}

    async def send(self, frame: str | bytes) -> bool:
        """Send a frame over the active managed duplex connection.

        Returns ``True`` when handed to an open connection, ``False`` when none is active (never
        connected, in a reconnect gap, or receive-only `connect_sse`) — the frame is dropped, like a
        browser WebSocket's send on a closed socket, so an adapter can pass ``client.send`` as a
        fire-and-forget callback; check `connected` (or the return) when it matters."""
        if self._sender is None:
            return False
        result = self._sender(frame)
        if inspect.isawaitable(result):
            await result
        return True

    async def propose(self, mid: int, new_value: Any, proposal: str | None = None) -> bool:
        """Propose an edit over the active connection: ``send(edit(mid, new_value))``.

        Server-authoritative — the mirror updates when the authoritative patch echoes back (or
        `on_reject` fires with why it was refused). Returns ``False`` (dropped) when not connected."""
        frame = self.edit(mid, new_value, proposal)
        return await self._send_proposal(frame)

    async def propose_ops(self, mid: int, ops: list[dict], proposal: str | None = None) -> bool:
        """Propose explicit patch operations over the active connection."""
        frame = self.edit_ops(mid, ops, proposal)
        return await self._send_proposal(frame)

    async def propose_crdt(self, mid: int, mutations: list[dict]) -> bool:
        """Apply local CRDT mutations immediately and retain them until an authoritative echo."""
        frame = self.edit_crdt(mid, mutations)
        return await self.send(frame)

    async def set_awareness(self, mid: int, state: Any | None) -> bool:
        """Publish ephemeral state for one model, or clear it with ``None``.

        The latest non-null state is retained locally and republished when a managed connection
        opens. This keeps presence visible across reconnects without adding it to durable state.
        """
        frame = protocol.encode(protocol.awareness_msg(mid, state), self._codec)
        if state is None:
            self._local_awareness.pop(mid, None)
        else:
            self._local_awareness[mid] = frame
        return await self.send(frame)

    async def _send_proposal(self, frame: str | bytes) -> bool:
        proposal = protocol.decode(frame, self._codec)["proposal"]
        try:
            sent = await self.send(frame)
        except Exception:
            self.abandon_proposal(proposal)
            raise
        if not sent:
            self.abandon_proposal(proposal)
        return sent

    def on_change(self, callback: Callable[[dict], None]) -> Callable[[], None]:
        """Register a callback fired after each accepted snapshot or patch — the same change dict
        `recv` returns — so `connect`/`run`/`connect_sse` consumers get path-level changes without
        managing the socket themselves. Not fired for ignored frames (stale revision, unknown message
        type). Returns an unsubscribe function."""
        self._change_cbs.append(callback)
        return lambda: self._change_cbs.remove(callback)

    def on_reject(self, callback: Callable[[dict], None]) -> Callable[[], None]:
        """Register a callback fired when the server refuses a proposed edit — with the decoded
        ``reject`` message (``{"t": "reject", "id", "rev", "error"}``). The mirror itself reverts via
        the authoritative snapshot the server sends alongside. Returns an unsubscribe function."""
        self._reject_cbs.append(callback)
        return lambda: self._reject_cbs.remove(callback)

    def on_awareness(self, callback: Callable[[dict], None]) -> Callable[[], None]:
        """Register for remote awareness updates and removals (``state`` is ``None``)."""
        self._awareness_cbs.append(callback)
        return lambda: self._awareness_cbs.remove(callback)

    def on_ack(self, callback: Callable[[dict], None]) -> Callable[[], None]:
        """Register a callback fired when the server accepts a tagged proposal.

        The callback receives an authoritative patch or no-op acknowledgement, including its opaque
        ``proposal`` identifier.
        Returns an unsubscribe function.
        """
        self._ack_cbs.append(callback)
        return lambda: self._ack_cbs.remove(callback)

    def on_disconnect(self, callback: Callable[[], None]) -> Callable[[], None]:
        """Register a callback fired when an active managed duplex connection disconnects."""
        self._disconnect_cbs.append(callback)
        return lambda: self._disconnect_cbs.remove(callback)

    def on_connect(self, callback: Callable[[], None]) -> Callable[[], None]:
        """Register a callback fired when a managed duplex connection opens, including reconnects."""
        self._connect_cbs.append(callback)
        return lambda: self._connect_cbs.remove(callback)

    def on_abandon(self, callback: Callable[[list[str]], None]) -> Callable[[], None]:
        """Register a callback fired with unsettled proposal identifiers on disconnect."""
        self._abandon_cbs.append(callback)
        return lambda: self._abandon_cbs.remove(callback)

    def _activate(self, sender: Callable[[str | bytes], Any]) -> None:
        if self._sender is not None and self._sender is not sender:
            self._sender = None
            self._disconnected()
        self._sender = sender
        for callback in list(self._connect_cbs):
            callback()

    async def attach(self, sender: Callable[[str | bytes], Any]) -> None:
        """Attach an open duplex channel and flush queued CRDT operations and awareness.

        Feed inbound frames to `recv`. When the channel closes, pass the same sender object to
        `detach`; sender identity prevents a late close from detaching a replacement channel. An
        existing channel is disconnected before its replacement is attached.
        """
        self._activate(sender)
        try:
            await self._flush_crdt_outbox(sender)
            await self._flush_awareness(sender)
        except Exception:
            self.detach(sender)
            raise

    def detach(self, sender: Callable[[str | bytes], Any]) -> bool:
        """Detach `sender` if it is still active, returning whether the client disconnected."""
        if self._sender is not sender:
            return False
        self._sender = None
        self._disconnected()
        return True

    def _disconnected(self) -> None:
        abandoned = json.loads(self._state.disconnect())["proposals"]
        if abandoned:
            for callback in list(self._abandon_cbs):
                callback(abandoned)
        for mid, peers in list(self._awareness.items()):
            for peer in list(peers):
                update = {"t": "awareness", "id": mid, "peer": peer, "state": None}
                for callback in list(self._awareness_cbs):
                    callback(update)
        self._awareness.clear()
        for callback in list(self._disconnect_cbs):
            callback()

    def _acknowledge(self, msg: dict) -> None:
        if "proposal" in msg:
            for callback in list(self._ack_cbs):
                callback(msg)

    def _accepted(self, change: dict) -> dict:
        for callback in list(self._change_cbs):
            callback(change)
        return change

    async def _flush_crdt_outbox(self, sender: Callable[[str | bytes], Any]) -> None:
        for pending in list(self._crdt_outbox):
            frame = protocol.encode(protocol.crdt_msg(pending["id"], pending["ops"]), self._codec)
            result = sender(frame)
            if inspect.isawaitable(result):
                await result

    async def _flush_awareness(self, sender: Callable[[str | bytes], Any]) -> None:
        for frame in list(self._local_awareness.values()):
            result = sender(frame)
            if inspect.isawaitable(result):
                await result

    def _settle_crdt_ops(self, mid: int, ops: list[dict]) -> None:
        echoed = {json.dumps(op["dot"], sort_keys=True) for op in ops if "dot" in op}
        retained = []
        for pending in self._crdt_outbox:
            if pending["id"] != mid:
                retained.append(pending)
                continue
            remaining = [op for op in pending["ops"] if json.dumps(op["dot"], sort_keys=True) not in echoed]
            if remaining:
                retained.append({"id": pending["id"], "ops": remaining})
        self._crdt_outbox = retained

    def recv(self, data: str | bytes) -> dict | None:
        """Apply an inbound snapshot or patch message (text or binary frame) to the local mirror.

        Returns the accepted change so reactive consumers can update only its paths —
        ``{"t": "snapshot", "id", "rev"}`` for a snapshot, the decoded patch message for a patch — or
        ``None`` for a patch whose revision was already applied, an ``ack``, a ``reject`` (dispatched
        to `on_reject`), and an unrecognized message type, which is ignored so a newer server can add
        message types without breaking older clients. A connection that negotiated ``?batch=1``
        may receive batch frames, which apply in order and return the accepted changes as a
        ``list``. Invalid frames raise without changing the mirror or its accepted revision."""
        msg = protocol.decode(data, self._codec)
        t = msg.get("t")
        if t == "batch":
            # a negotiated batch frame: apply each message in order; the accepted changes come
            # back as a list (only connections that requested ?batch=1 ever receive these)
            accepted = [self._recv_msg(m) for m in msg["msgs"]]
            return [a for a in accepted if a is not None] or None
        return self._recv_msg(msg)

    def _recv_msg(self, msg: dict) -> dict | None:
        effect_json = self._state.prepare(json.dumps(msg))
        effect = json.loads(effect_json)
        kind = effect["effect"]
        if kind == "snapshot":
            mid: int = msg["id"]
            self._crdt.pop(mid, None)
            self._crdt_outbox = [pending for pending in self._crdt_outbox if pending["id"] != mid]
            self._values[mid] = msg["value"]
            self._type[mid] = msg["type"]
            self._state.commit(effect_json)
            return self._accepted({"t": "snapshot", "id": mid, "rev": msg["rev"]})
        elif kind == "crdt_snapshot":
            mid = msg["id"]
            spec = CrdtSpec.from_dict(msg["spec"])
            document = CrdtDocument.from_state(spec, msg["state"], self._replica)
            for pending in self._crdt_outbox:
                if pending["id"] == mid:
                    document.apply(pending["ops"])
            self._crdt[mid] = document
            self._values[mid] = _value_of(document.value)
            self._type[mid] = msg["type"]
            self._state.commit(effect_json)
            return self._accepted({"t": "crdt_snapshot", "id": mid, "rev": msg["rev"]})
        elif kind == "patch":
            mid = msg["id"]
            value = json.loads(_apply(json.dumps(self._values[mid]), json.dumps(msg["patch"])))
            self._state.commit(effect_json)
            self._values[mid] = value
            accepted = self._accepted(msg)
            self._acknowledge(msg)
            return accepted
        elif kind == "crdt":
            mid = msg["id"]
            document = self._crdt.get(mid)
            if document is None:
                raise ValueError(f"CRDT operations received before CRDT snapshot for model {mid}")
            document.apply(msg["ops"])
            self._values[mid] = _value_of(document.value)
            self._state.commit(effect_json)
            self._settle_crdt_ops(mid, msg["ops"])
            accepted = self._accepted(msg)
            self._acknowledge(msg)
            return accepted
        elif kind == "stale_patch" or kind == "acknowledgement":
            self._state.commit(effect_json)
            self._acknowledge(msg)
            return None
        elif kind == "rejection":
            self._state.commit(effect_json)
            if "crdt_ops" in msg:
                self._settle_crdt_ops(msg["id"], msg["crdt_ops"])
            for callback in list(self._reject_cbs):
                callback(msg)
            return None
        elif kind == "awareness":
            mid = msg["id"]
            peer = msg["peer"]
            state = msg.get("state")
            peers = self._awareness.setdefault(mid, {})
            if state is None:
                peers.pop(peer, None)
                if not peers:
                    self._awareness.pop(mid, None)
            else:
                peers[peer] = state
            for callback in list(self._awareness_cbs):
                callback(msg)
            return None
        # an unrecognized message type is ignored (not an error): the server may be newer than this client
        return None

    def value(self, mid: int) -> Any:
        """The current mirrored core `Value` of a model."""
        return self._values[mid]

    def crdt_spec(self, mid: int) -> CrdtSpec | None:
        """The canonical merge specification for a CRDT-backed model, else ``None``."""
        document = self._crdt.get(mid)
        return None if document is None else document.spec

    def model(self, mid: int, cls: type[M]) -> M:
        """Materialize the mirrored model as an instance of `cls`."""
        return from_value(self._values[mid], cls)

    def ids(self) -> list[int]:
        return list(self._values)

    def pending_proposals(self) -> list[str]:
        """Identifiers for proposals that have not settled or been abandoned."""
        return self._state.pending()

    def pending_crdt_ops(self, mid: int | None = None) -> int:
        """Number of local CRDT operations awaiting an authoritative echo."""
        return sum(len(pending["ops"]) for pending in self._crdt_outbox if mid is None or pending["id"] == mid)

    def awareness(self, mid: int) -> dict[str, Any]:
        """Snapshot remote ephemeral state keyed by server-assigned peer id."""
        return dict(self._awareness.get(mid, {}))

    def abandon_proposal(self, proposal: str) -> bool:
        """Stop tracking one proposal that the caller did not send.

        Returns whether the proposal was pending. This does not call `on_abandon`; those callbacks
        report proposals abandoned by a managed connection closing.
        """
        return self._state.abandon(proposal)

    def edit(self, mid: int, new_value: Any, proposal: str | None = None) -> str | bytes:
        """Propose an edit to a mirrored model; returns the patch frame to send (encoded in this codec).

        Models are server-authoritative: the edit is a proposal, and the local mirror updates only
        when the server echoes the authoritative patch back (via `recv`), not optimistically. This
        keeps `rev` owned by the server and avoids client/server `rev` divergence.
        """
        patch = json.loads(_diff(json.dumps(self._values[mid]), json.dumps(new_value)))
        return self.edit_ops(mid, patch["ops"], proposal)

    def edit_ops(self, mid: int, ops: list[dict], proposal: str | None = None) -> str | bytes:
        """Propose explicit patch operations, optionally under a caller-supplied identifier.

        When ``proposal`` is omitted, a client-local monotonic identifier is assigned. Use this
        form when a new optimistic value equals the current mirror and a whole-value diff would be
        empty while an older proposal is still pending.
        """
        message = self._state.proposal(mid, json.dumps(ops), proposal)
        try:
            return protocol.encode(message, self._codec)
        except Exception:
            self.abandon_proposal(json.loads(message)["proposal"])
            raise

    def edit_crdt(self, mid: int, mutations: list[dict]) -> str | bytes:
        """Apply local CRDT mutations and return an idempotent operation frame.

        Operations remain queued until the server echoes their causal dots. Reconnects restore the
        server snapshot, reapply queued operations locally, and resend them.
        """
        document = self._crdt.get(mid)
        if document is None:
            raise KeyError(f"model {mid} is not CRDT-backed")
        change = document.mutate(mutations)
        self._values[mid] = _value_of(document.value)
        if change["ops"]:
            self._crdt_outbox.append({"id": mid, "ops": change["ops"]})
        return protocol.encode(protocol.crdt_msg(mid, change["ops"]), self._codec)

    def _connect_url(self, url: str) -> str:
        """``url`` + ``?codec=``, plus ``?since=`` (last-seen rev per model) when this client already
        mirrors models, so a reconnect resumes from the delta instead of re-sending each whole model."""
        sep = "&" if "?" in url else "?"
        params = f"codec={self._codec}"
        revisions = self._state.revisions()
        if revisions != "{}":
            params += "&since=" + urllib.parse.quote(revisions)
        return f"{url}{sep}{params}"

    async def connect(self, url: str) -> None:
        """Connect to a transports server and mirror it until the connection closes (one connection).

        Under Pyodide (``sys.platform == "emscripten"``) the browser gives Python no raw sockets, so
        this rides the browser's native ``WebSocket`` through the ``js`` FFI instead of the
        ``websockets`` library — same API, same wire."""
        if sys.platform == "emscripten":  # pragma: no cover - exercised by the in-Pyodide suite
            await self._connect_browser(url)
            return
        import websockets

        async with websockets.connect(self._connect_url(url)) as ws:
            sender = ws.send
            try:
                await self.attach(sender)
                async for frame in ws:
                    self.recv(frame)
            finally:
                self.detach(sender)

    async def _run_browser(self, url: str, *, authority: str = "server", retry: float = 1.0) -> None:
        """`run` over the browser's native `WebSocket` (the Pyodide path): reconnect forever with
        ``?since=`` resume, same ``authority`` semantics as the native loop."""
        import asyncio

        while True:
            pre = dict(self._values) if authority == "client" else None
            pushed: set = set()

            def _rectify(ws: Any, pre: dict | None = pre, pushed: set = pushed) -> None:
                if not pre:  # server-authoritative (or nothing mirrored before the drop)
                    return
                for mid in list(self._values):
                    if mid not in pushed and mid in pre and mid not in self._crdt:
                        self._send_browser(ws, self.edit(mid, pre[mid]))
                        pushed.add(mid)

            # construction/FFI errors fall through to the retry, like the native loop's dropped socket
            with contextlib.suppress(Exception):
                await self._connect_browser(url, on_frame=_rectify)
            await asyncio.sleep(retry)

    @staticmethod
    def _send_browser(ws: Any, frame: str | bytes) -> None:
        """Send a frame over a browser channel: text as-is, binary converted for the FFI."""
        if isinstance(frame, str):
            ws.send(frame)
        else:
            from pyodide.ffi import to_js

            ws.send(to_js(frame))

    async def _connect_browser(self, url: str, on_frame: Callable[[Any], None] | None = None) -> None:
        """Mirror over the browser's native `WebSocket` (the Pyodide path) until it closes.

        ``on_frame(ws)`` fires after each applied frame — `_run_browser` uses it to rectify under
        client authority. Split out (and importing ``js`` / ``pyodide.ffi`` lazily) so the wiring is
        testable with fake modules injected into ``sys.modules`` off-browser."""
        import asyncio

        from pyodide.ffi import create_proxy

        from js import WebSocket  # the browser global via the Pyodide FFI

        ws = WebSocket.new(self._connect_url(url))
        ws.binaryType = "arraybuffer"
        closed: asyncio.Future = asyncio.get_running_loop().create_future()
        sender = lambda frame: self._send_browser(ws, frame)
        opened = False

        def _on_message(event: Any) -> None:
            data = event.data
            # a text frame arrives as str; a binary frame as an ArrayBuffer proxy -> bytes
            self.recv(data if isinstance(data, str) else bytes(data.to_bytes()))
            if on_frame is not None:
                on_frame(ws)

        def _on_close(_event: Any) -> None:
            if not closed.done():
                closed.set_result(None)

        def _on_open(_event: Any) -> None:
            nonlocal opened
            # arm the outbound channel only once the socket is open (send during CONNECTING throws)
            opened = True
            self._activate(sender)
            asyncio.create_task(self._flush_crdt_outbox(sender))

        proxies = [create_proxy(_on_message), create_proxy(_on_open), create_proxy(_on_close), create_proxy(_on_close)]
        for name, proxy in zip(("message", "open", "close", "error"), proxies):
            ws.addEventListener(name, proxy)
        try:
            await closed
        finally:
            if opened:
                self.detach(sender)
            for proxy in proxies:
                proxy.destroy()

    async def connect_data_channel(self, channel: Any) -> None:
        """Mirror over an externally negotiated browser ``RTCDataChannel`` until it closes.

        Signaling and peer-connection ownership stay with the application. Under Pyodide the
        channel rides the browser's ``js`` FFI; native Python deliberately has no ``aiortc``
        dependency.
        """
        import asyncio

        from pyodide.ffi import create_proxy

        channel.binaryType = "arraybuffer"
        closed: asyncio.Future = asyncio.get_running_loop().create_future()
        sender = lambda frame: self._send_browser(channel, frame)
        attachment: asyncio.Task | None = None

        def _on_message(event: Any) -> None:
            data = event.data
            self.recv(data if isinstance(data, str) else bytes(data.to_bytes()))

        def _on_close(_event: Any) -> None:
            if not closed.done():
                closed.set_result(None)

        def _on_open(_event: Any) -> None:
            nonlocal attachment
            attachment = asyncio.create_task(self.attach(sender))

            def _attached(task: asyncio.Task) -> None:
                if not task.cancelled() and task.exception() is not None and not closed.done():
                    closed.set_exception(task.exception())

            attachment.add_done_callback(_attached)

        proxies = [create_proxy(_on_message), create_proxy(_on_open), create_proxy(_on_close)]
        for name, proxy in zip(("message", "open", "close"), proxies):
            channel.addEventListener(name, proxy)
        try:
            if channel.readyState == "open":
                await self.attach(sender)
            elif channel.readyState == "closed":
                return
            await closed
        finally:
            if attachment is not None and not attachment.done():
                attachment.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await attachment
            self.detach(sender)
            for proxy in proxies:
                proxy.destroy()

    async def run(self, url: str, *, authority: str = "server", retry: float = 1.0) -> None:
        """Connect and mirror, **reconnecting** whenever the connection drops — so the client survives a
        server restart or a network blip. ``authority`` decides reconciliation on each (re)connect:

        - ``"server"`` (default): the server is canonical; the client adopts its state (resuming from
          ``?since=`` when it can, else a fresh snapshot). This is the "refetch on refresh" behavior.
        - ``"client"``: the client is canonical; after the server's snapshot it **pushes its last-known
          state back** as an edit, so a server that came back stale or empty is rectified from the client.
          With a CRDT model the push merges (newer stamps win); otherwise it overwrites.

        Runs until cancelled. The choice of *where the authoritative state lives* is yours — pair this
        with the server-side durability hooks (`Hub.on_shared_write`) as your use case needs. Under
        Pyodide this rides the browser's native ``WebSocket`` (like `connect`), same semantics.
        """
        import asyncio

        if authority not in ("server", "client"):
            raise ValueError(f"authority must be 'server' or 'client', not {authority!r}")
        if sys.platform == "emscripten":  # pragma: no cover - exercised by the in-Pyodide suite
            await self._run_browser(url, authority=authority, retry=retry)
            return

        import websockets

        while True:
            pre = dict(self._values) if authority == "client" else None
            pushed: set = set()
            try:
                async with websockets.connect(self._connect_url(url)) as ws:
                    sender = ws.send
                    try:
                        await self.attach(sender)
                        async for frame in ws:
                            self.recv(frame)
                            if pre:  # rectify: once the server has (re)snapshotted a model, push our copy back
                                for mid in list(self._values):
                                    if mid not in pushed and mid in pre and mid not in self._crdt:
                                        await ws.send(self.edit(mid, pre[mid]))
                                        pushed.add(mid)
                    finally:
                        self.detach(sender)
            except (websockets.ConnectionClosed, OSError):
                pass  # dropped — fall through to retry
            await asyncio.sleep(retry)

    async def connect_sse(self, url: str) -> None:
        """Mirror a transports server over Server-Sent Events (receive-only) until the stream closes.

        SSE is a one-way server→client channel, so this only receives snapshots and patches; use
        `connect()` (WebSocket) when the client also needs to send edits. Under Pyodide this rides
        the browser's native ``EventSource`` (no raw sockets for `httpx`).
        """
        if sys.platform == "emscripten":  # pragma: no cover - exercised by the in-Pyodide suite
            await self._connect_sse_browser(url)
            return
        import httpx
        from httpx_sse import aconnect_sse

        async with httpx.AsyncClient() as http, aconnect_sse(http, "GET", url) as source:
            async for event in source.aiter_sse():
                self.recv(event.data)

    async def _connect_sse_browser(self, url: str) -> None:
        """Mirror over the browser's native `EventSource` (the Pyodide path) until it errors/closes."""
        import asyncio

        from pyodide.ffi import create_proxy

        from js import EventSource  # the browser global via the Pyodide FFI

        source = EventSource.new(url)
        closed: asyncio.Future = asyncio.get_running_loop().create_future()

        def _on_message(event: Any) -> None:
            self.recv(event.data)  # SSE is text-only

        def _on_error(_event: Any) -> None:
            if not closed.done():
                closed.set_result(None)

        on_message, on_error = create_proxy(_on_message), create_proxy(_on_error)
        source.addEventListener("message", on_message)
        source.addEventListener("error", on_error)
        try:
            await closed
        finally:
            source.close()
            on_message.destroy()
            on_error.destroy()
